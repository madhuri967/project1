package com.example.demo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

@Controller
@RequestMapping("/abjj")
public class LoginController {

	@GetMapping("/userInfo")
	public String userInfo(
	    @RequestParam("userId") String userId, 
	    @RequestParam("password") String password, 
	    Model model) {
    	model.addAttribute("userId", userId);
        model.addAttribute("passwordAttempt", password);
        return "userInfoDisplay";
    }
    @PostMapping("/createUserInfo")
    public String createUserInfo(
            @RequestParam("newUserId") String newUserId,
            @RequestParam("newPassword") String newPassword,
            Model model) {
    	 model.addAttribute("createdUserId", newUserId);
         model.addAttribute("createdPassword", newPassword);
         model.addAttribute("message", "User Information for '" + newUserId + "' received successfully via POST!");

         return "postSuccessPage";
    }
}