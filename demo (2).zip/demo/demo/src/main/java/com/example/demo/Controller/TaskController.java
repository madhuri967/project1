package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.TaskDTO;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.TaskService;

@RestController
@RequestMapping("/task")
public class TaskController {

	@Autowired
	TaskService taskService;
	@Autowired
	private UserRepository userRepository;
	

	@GetMapping
    public ResponseEntity<List<TaskDTO>> getTasks(@RequestParam(value = "count", required = false, defaultValue = "0") int count) {
         User user=new User();
         user.setId("2");
         user.setEmail("abc@gmail.com");
        user.setName("test");
        userRepository.save(user); 

       
        List<TaskDTO> tasks = taskService.getAllTasks(); 
        return new ResponseEntity<>(tasks, HttpStatus.OK);
    }
	
	@GetMapping("/{taskId}")
	public ResponseEntity<TaskDTO> getTasksById(@PathVariable("taskId") int taskId) {
		TaskDTO task = taskService.getTaskById(taskId);
		if (task != null) {
			System.out.println("Task Name : " + task.getTaskName() + " is the taskName of id :" + taskId);
			return new ResponseEntity<>(task, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping
	public ResponseEntity<Boolean> postTasks(@RequestBody TaskDTO taskdetails) {
		boolean added = taskService.addTask(taskdetails);
		if (added) {
			System.out.println("Task added successfully: " + taskdetails.toString());
			return new ResponseEntity<>(true, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
		}
	}

	@PutMapping
	public void updateTasks() {
		System.out.println("Inside Update Tasks");
	}

	@PutMapping("/{taskId}")
	public void updateTaskById(@PathVariable("taskId") int tId) {
		System.out.println("Inside Update By Id  Tasks");
	}

	@DeleteMapping
	public void DeleteTasks() {
		System.out.println("Inside Delete Tasks");
	}

}