package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dto.TaskDTO;

@Service
public class TaskService {

    public static List<TaskDTO> taskDetails = new ArrayList<>();

    public boolean addTask(TaskDTO task) {
        boolean added = taskDetails.add(task);
        System.out.println("Task added to service: " + task.toString());
        return added;
    }

    public List<TaskDTO> getAllTasks() {
        return taskDetails;
    }

    public TaskDTO getTaskById(int taskId) {
        for (TaskDTO task : taskDetails) {
            if (task.getTaskId() == taskId) {
                return task;
            }
        }
        return null;
    }

	public Object getTask() {
		// TODO Auto-generated method stub
		return null;
	}
}